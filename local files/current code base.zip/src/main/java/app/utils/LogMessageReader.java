package app.utils;

import app.model.LogMessage;
import app.model.LogMessageInterface;
import app.model.RawLogEntry;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;

public final class LogMessageReader implements Runnable, AutoCloseable {
    private final BlockingQueue<RawLogEntry> input;
    private final BlockingQueue<LogMessageInterface> enrichmentQueue;
    private final Gson gson;
    private final Consumer<Throwable> errorHandler;
    private final AtomicBoolean running = new AtomicBoolean(true);

    public LogMessageReader(BlockingQueue<RawLogEntry> input,
                            BlockingQueue<LogMessageInterface> enrichmentQueue,
                            Gson gson,
                            Consumer<Throwable> errorHandler) {
        this.input = input;
        this.enrichmentQueue = enrichmentQueue;
        this.gson = gson;
        this.errorHandler = errorHandler;
    }

    @Override
    public void run() {
        while (running.get()) {
            try {
                RawLogEntry raw = input.take();
                enrichmentQueue.put(parse(raw));
            } catch (InterruptedException interrupted) {
                Thread.currentThread().interrupt();
                running.set(false);
            } catch (Throwable error) {
                errorHandler.accept(error);
            }
        }
    }

    private LogMessageInterface parse(RawLogEntry raw) {
        LogMessage message = new LogMessage();
        message.setSequence(raw.getSequence());
        message.setTimestamp(raw.getTimestamp());
        message.setRawText(raw.getText());
        message.setCategory(classify(raw.getText()));
        message.setDisplayText(summarize(raw.getText()));
        message.setReferencedCardIds(extractCardIds(raw.getText()));
        return message;
    }

    private String classify(String line) {
        if (line.contains("DETAILED LOGS")) return "SYSTEM";
        if (line.contains("ResultReason_") || line.contains("MatchState_GameComplete")) return "RESULT";
        if (line.contains("Connecting to matchId") || line.contains("matchGameRoomStateChangedEvent")) return "MATCH";
        if (line.contains("GameStateMessage") || line.contains("greToClientEvent")) return "GAME";
        return "RAW";
    }

    private String summarize(String line) {
        String trimmed = line.strip();
        if (!trimmed.startsWith("{")) {
            return trimmed;
        }
        try {
            JsonObject root = JsonParser.parseString(trimmed).getAsJsonObject();
            if (root.has("matchGameRoomStateChangedEvent")) {
                JsonObject event = root.getAsJsonObject("matchGameRoomStateChangedEvent");
                String state = stringAt(event, "stateType");
                String matchId = stringAt(event, "gameRoomInfo", "gameRoomConfig", "matchId");
                return "Match state=" + state + (matchId.isBlank() ? "" : " matchId=" + matchId);
            }
            if (root.has("greToClientEvent")) {
                JsonArray messages = root.getAsJsonObject("greToClientEvent").getAsJsonArray("greToClientMessages");
                if (messages != null && !messages.isEmpty()) {
                    return "GRE " + stringAt(messages.get(0).getAsJsonObject(), "type");
                }
                return "GRE event";
            }
            return gson.toJson(root);
        } catch (RuntimeException malformed) {
            return trimmed;
        }
    }

    private Set<Long> extractCardIds(String line) {
        Set<Long> result = new LinkedHashSet<>();
        String trimmed = line.stripLeading();
        if (!trimmed.startsWith("{")) return result;
        try {
            collectGrpIds(JsonParser.parseString(trimmed), result);
        } catch (RuntimeException ignored) {
        }
        return result;
    }

    private void collectGrpIds(JsonElement element, Set<Long> target) {
        if (element == null || element.isJsonNull()) return;
        if (element.isJsonArray()) {
            for (JsonElement child : element.getAsJsonArray()) collectGrpIds(child, target);
            return;
        }
        if (!element.isJsonObject()) return;

        JsonObject object = element.getAsJsonObject();
        String objectType = stringAt(object, "type");
        if (object.has("grpId") && object.has("instanceId")
                && !"GameObjectType_Ability".equals(objectType)) {
            JsonElement value = object.get("grpId");
            if (value.isJsonPrimitive() && value.getAsJsonPrimitive().isNumber()) {
                long id = value.getAsLong();
                if (id > 0) target.add(id);
            }
        }
        if (object.has("objectSourceGrpId")) {
            JsonElement value = object.get("objectSourceGrpId");
            if (value.isJsonPrimitive() && value.getAsJsonPrimitive().isNumber()) {
                long id = value.getAsLong();
                if (id > 0) target.add(id);
            }
        }
        for (var entry : object.entrySet()) collectGrpIds(entry.getValue(), target);
    }

    private String stringAt(JsonObject root, String... path) {
        JsonElement current = root;
        for (String key : path) {
            if (current == null || !current.isJsonObject()) return "";
            current = current.getAsJsonObject().get(key);
        }
        return current == null || current.isJsonNull() ? "" : current.getAsString();
    }

    @Override
    public void close() {
        running.set(false);
    }
}
