package app.utils;

import java.util.List;

public final class LogLineFilter {
    private static final List<String> MARKERS = List.of(
            "DETAILED LOGS:",
            "Connecting to matchId",
            "matchGameRoomStateChangedEvent",
            "greToClientEvent",
            "ClientToGremessage",
            "ClientToGREMessage",
            "ClientMessageType_",
            "GameStateMessage",
            "MatchGameRoomStateType_",
            "ResultReason_"
    );

    private LogLineFilter() {
    }

    public static boolean isInteresting(String line) {
        if (line == null || line.isBlank()) {
            return false;
        }
        if (line.stripLeading().startsWith("{")) {
            return true;
        }
        return MARKERS.stream().anyMatch(line::contains);
    }
}
