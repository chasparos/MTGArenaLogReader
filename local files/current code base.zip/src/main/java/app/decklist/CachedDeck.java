package app.decklist;

import java.time.Instant;
import java.util.List;

public record CachedDeck(
        String deckId,
        String name,
        String format,
        String eventName,
        Instant updatedAt,
        List<DeckEntry> mainDeck,
        List<DeckEntry> sideboard,
        List<DeckEntry> commandZone,
        List<DeckEntry> companions
) {
    public int mainDeckSize() {
        return mainDeck.stream().mapToInt(DeckEntry::quantity).sum();
    }
}
