package app.decklist;

import app.model.CardInfo;

public record DeckEntry(long arenaId, int quantity, CardInfo card) {
    public String displayName() {
        return card != null && card.getName() != null ? card.getName() : "ArenaCard#" + arenaId;
    }
}
