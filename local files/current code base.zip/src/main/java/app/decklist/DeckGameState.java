package app.decklist;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

public record DeckGameState(
        String matchId,
        int gameNumber,
        CachedDeck deck,
        int libraryCount,
        int graveyardCount,
        int exileCount,
        Map<Long,Integer> knownOutsideLibrary,
        boolean complete
) {
    public DeckGameState {
        knownOutsideLibrary = knownOutsideLibrary == null
                ? Map.of() : Collections.unmodifiableMap(new LinkedHashMap<>(knownOutsideLibrary));
    }

    public int remainingCopies(long arenaId, int originalQuantity) {
        return Math.max(0, originalQuantity - knownOutsideLibrary.getOrDefault(arenaId, 0));
    }

    public double drawPercent(long arenaId, int originalQuantity) {
        if (libraryCount <= 0) return 0.0;
        return 100.0 * remainingCopies(arenaId, originalQuantity) / libraryCount;
    }
}
