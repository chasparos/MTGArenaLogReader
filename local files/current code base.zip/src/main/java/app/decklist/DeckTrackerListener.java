package app.decklist;

public interface DeckTrackerListener {
    void gameStarted(DeckGameState state);
    void gameUpdated(DeckGameState state);
    void gameCompleted(String matchId, int gameNumber);
}
