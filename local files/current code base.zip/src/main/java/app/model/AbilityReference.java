package app.model;

import lombok.Data;

@Data
public class AbilityReference {
    private long abilityGrpId;
    private long sourceGrpId;
    private String sourceName;
    private String kind;

    public String key() { return sourceGrpId + ":" + abilityGrpId; }
}
