package app.model;

import java.time.Instant;
import java.util.Set;
import java.util.concurrent.CompletableFuture;

public interface LogMessageInterface {
    long getSequence();
    Instant getTimestamp();
    String getCategory();
    String getDisplayText();
    String getRawText();
    Set<Long> getReferencedCardIds();
    CompletableFuture<ModelObject> getModelFuture();
}
