package app.model;

import com.google.gson.annotations.SerializedName;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class CardFaceInfo {
    private String name;
    @SerializedName("mana_cost") private String manaCost;
    @SerializedName("type_line") private String typeLine;
    @SerializedName("oracle_text") private String oracleText;
    private String power;
    private String toughness;
    private String loyalty;
    private String defense;
    private List<String> colors = new ArrayList<>();
    @SerializedName("color_indicator") private List<String> colorIndicator = new ArrayList<>();
    @SerializedName("image_uris") private CardImageUris imageUris;
    @SerializedName("artist") private String artist;
    @SerializedName("artist_id") private String artistId;
    @SerializedName("illustration_id") private String illustrationId;
    private String watermark;
    @SerializedName("flavor_text") private String flavorText;
    @SerializedName("flavor_name") private String flavorName;

    public String previewImageUrl() {
        return imageUris == null ? null : imageUris.preferredPreviewUrl();
    }
}
