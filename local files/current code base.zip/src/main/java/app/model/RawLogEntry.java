package app.model;

import lombok.Value;

import java.time.Instant;

@Value
public class RawLogEntry {
    long sequence;
    Instant timestamp;
    String text;
}
