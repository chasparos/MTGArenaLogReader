package app.model;

import lombok.Data;
import java.util.ArrayList;
import java.util.List;

/** Player resources captured at the first reliable state update of a turn. */
@Data
public class PlayerTurnSnapshot {
    private int seatId;
    private String playerName;
    private Integer lifeTotal;
    private Integer poisonCounters;
    private Integer handSize;
    private final List<BoardPermanentSnapshot> battlefield = new ArrayList<>();
}
