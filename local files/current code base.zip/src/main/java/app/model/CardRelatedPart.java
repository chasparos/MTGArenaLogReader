package app.model;

import com.google.gson.annotations.SerializedName;
import lombok.Data;

/** A related Scryfall card/token/emblem object from all_parts. */
@Data
public class CardRelatedPart {
    private String id;
    private String component;
    private String name;
    @SerializedName("type_line") private String typeLine;
    private String uri;
}
