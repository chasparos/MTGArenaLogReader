package app.model;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/** Immutable-by-convention view of one permanent for a start-of-turn board snapshot. */
@Data
public class BoardPermanentSnapshot {
    private long logicalObjectId;
    private int ownerSeatId;
    private int controllerSeatId;
    private String name;
    private CardInfo card;
    private Boolean tapped;
    private Integer power;
    private Integer toughness;
    /** Logical object id of the permanent this card is attached to, if any. */
    private Long attachedToLogicalObjectId;
    private final List<CounterState> counters = new ArrayList<>();
}
