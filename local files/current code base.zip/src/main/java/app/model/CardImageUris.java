package app.model;

import com.google.gson.annotations.SerializedName;
import lombok.Data;

@Data
public class CardImageUris {
    private String small;
    private String normal;
    private String large;
    private String png;
    @SerializedName("art_crop") private String artCrop;
    @SerializedName("border_crop") private String borderCrop;

    public String preferredPreviewUrl() {
        if (normal != null && !normal.isBlank()) return normal;
        if (small != null && !small.isBlank()) return small;
        if (large != null && !large.isBlank()) return large;
        if (png != null && !png.isBlank()) return png;
        return null;
    }
}
