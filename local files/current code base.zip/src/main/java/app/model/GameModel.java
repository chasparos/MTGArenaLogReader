package app.model;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class GameModel {
    private String matchId;
    private int gameNumber;
    private String openingHandPlayer;
    private int mulliganCount;
    private final List<CardInfo> openingHand = new ArrayList<>();
    private final List<GameEvent> events = new ArrayList<>();
    private final List<String> rawRecords = new ArrayList<>();

    public synchronized void addEvents(List<GameEvent> additions) { events.addAll(additions); }
    public synchronized void addRawRecord(String raw) {
        if (raw != null && !raw.isBlank()) rawRecords.add(raw);
    }
    public synchronized List<String> rawRecordSnapshot() { return List.copyOf(rawRecords); }
    public synchronized List<GameEvent> snapshot() { return List.copyOf(events); }
    public synchronized void setOpeningHand(String player, int mulligans, List<CardInfo> cards) {
        openingHandPlayer = player;
        mulliganCount = mulligans;
        openingHand.clear();
        openingHand.addAll(cards);
    }
    public synchronized List<CardInfo> openingHandSnapshot() { return List.copyOf(openingHand); }
    public synchronized boolean isComplete() {
        return events.stream().anyMatch(e -> e.getGameResult() != null || "Game completed".equals(e.getText()));
    }
    public synchronized void clear() { events.clear(); rawRecords.clear(); openingHand.clear(); openingHandPlayer = null; mulliganCount = 0; }
}
