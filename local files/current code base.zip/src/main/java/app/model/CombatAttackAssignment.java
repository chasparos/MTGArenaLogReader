package app.model;

/** Objective Arena combat assignment for one attacker. */
public record CombatAttackAssignment(
        long attackerLogicalId,
        long attackerInstanceId,
        String attackerName,
        int controllerSeatId,
        long targetId,
        String targetName
) {}
