package app.model;

import lombok.Data;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Data
public class GameEvent {
    private long sequence;
    private Instant timestamp;
    private Integer turnNumber;
    private Integer activePlayerSeat;
    private String activePlayerName;
    private String phase;
    private String step;
    private String text;
    private final List<CardInfo> cards = new ArrayList<>();
    private AbilityReference ability;
    private final List<PlayerTurnSnapshot> turnSnapshot = new ArrayList<>();
    private final List<CombatAttackAssignment> attackers = new ArrayList<>();
    private final List<CombatBlockAssignment> blockers = new ArrayList<>();
    /** Canonical battlefield observation consumed by BoardStateMonitor. */
    private final List<BoardPermanentSnapshot> battlefieldObservation = new ArrayList<>();
    private GameResult gameResult;
}
