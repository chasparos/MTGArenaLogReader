package app.model;

import lombok.Data;

/** Canonical Arena counter information. Counter types are retained even when the UI does not render them yet. */
@Data
public class CounterState {
    /** Raw Arena counter_type value. Unknown values are preserved. */
    private int arenaType = -1;
    /** Human-readable type when known, otherwise Counter#N. */
    private String type = "";
    private int count;

    public CounterState copy() {
        CounterState copy = new CounterState();
        copy.arenaType = arenaType;
        copy.type = type;
        copy.count = count;
        return copy;
    }
}
