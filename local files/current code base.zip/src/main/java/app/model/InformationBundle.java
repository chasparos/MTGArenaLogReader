package app.model;

import lombok.Data;

import java.util.LinkedHashMap;
import java.util.Map;

@Data
public class InformationBundle implements ModelObject {
    private final Map<Long, CardInfo> cards = new LinkedHashMap<>();
    private final Map<String, CardInfo> relatedCards = new LinkedHashMap<>();
}
