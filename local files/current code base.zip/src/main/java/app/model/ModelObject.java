package app.model;

/** Marker for asynchronously attached information. */
public interface ModelObject {
}
