package app.model;

import lombok.Data;

import java.time.Instant;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.concurrent.CompletableFuture;

@Data
public class LogMessage implements LogMessageInterface {
    private long sequence;
    private Instant timestamp = Instant.now();
    private String category;
    private String displayText;
    private String rawText;
    private Set<Long> referencedCardIds = new LinkedHashSet<>();
    private CompletableFuture<ModelObject> modelFuture = new CompletableFuture<>();
}
