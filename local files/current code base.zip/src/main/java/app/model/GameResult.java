package app.model;

import lombok.Data;

/** Human-facing result reconstructed from Arena gameInfo plus the final canonical state. */
@Data
public class GameResult {
    public enum Reason { DAMAGE, POISON, EMPTY_LIBRARY, CONCEDE, EFFECT, OTHER, DRAW, UNKNOWN }
    public enum Confidence { EXPLICIT, CORRELATED, INFERRED }

    private Integer winnerSeatId;
    private String winnerName;
    private Integer loserSeatId;
    private String loserName;
    private Reason reason = Reason.UNKNOWN;
    private Confidence confidence = Confidence.INFERRED;
    private String finishingCard;
}
