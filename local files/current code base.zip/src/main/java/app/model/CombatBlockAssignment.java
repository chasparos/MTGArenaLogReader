package app.model;

import java.util.List;

/** Objective Arena combat assignment for one blocker. */
public record CombatBlockAssignment(
        long blockerLogicalId,
        long blockerInstanceId,
        String blockerName,
        int controllerSeatId,
        List<Long> attackerLogicalIds,
        List<String> attackerNames
) {
    public CombatBlockAssignment {
        attackerLogicalIds = List.copyOf(attackerLogicalIds);
        attackerNames = List.copyOf(attackerNames);
    }
}
