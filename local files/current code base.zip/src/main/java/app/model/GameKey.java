package app.model;

import lombok.Data;

import java.util.Objects;

@Data
public final class GameKey {
    private final String matchId;
    private final int gameNumber;

    public GameKey(String matchId, int gameNumber) {
        this.matchId = Objects.requireNonNullElse(matchId, "unknown-match");
        this.gameNumber = Math.max(1, gameNumber);
    }

    public String displayName() {
        String shortMatch = matchId.length() > 8 ? matchId.substring(0, 8) : matchId;
        return "Game " + gameNumber + " · " + shortMatch;
    }
}
