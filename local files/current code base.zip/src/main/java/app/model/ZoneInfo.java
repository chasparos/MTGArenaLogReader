package app.model;

import lombok.Data;

@Data
public class ZoneInfo {
    private int zoneId;
    private String type;
    private Integer ownerSeatId;
    private int objectCount = -1;

    public String displayName() {
        if (type == null || type.isBlank()) {
            return "Zone " + zoneId;
        }
        String value = type.startsWith("ZoneType_") ? type.substring("ZoneType_".length()) : type;
        return value.replace('_', ' ');
    }
}
